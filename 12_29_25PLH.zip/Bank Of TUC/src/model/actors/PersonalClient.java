package model.actors;

import java.util.ArrayList;
import java.util.List;


public class PersonalClient extends Client {
	
	private ArrayList<PersonalAccount> accounts;
	
    
	//___________________________________________________________________________|constructor|	
	public PersonalClient(String username, String password, String fullName,
				  		  String afm, String phone) 
	{
	
		super(username, password, fullName, afm, phone);
		this.accounts = new ArrayList<>();
	
	}	
    //________________________________________________________________________________________
	
    public void addPersonalAccount(PersonalAccount p) {
		
    	if(p!=null) {accounts.add(p);}
	}

	public ArrayList<PersonalAccount> getAccounts() {

		return accounts;	
	}
	
	@Override
	public void viewAccountBalance() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void viewTransactionHistory() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public String toString() {
	    StringBuilder sb = new StringBuilder();

	    sb.append("PersonalClient {\n");
	    sb.append("  fullName: ").append(fullName).append("\n");
	    sb.append("  username: ").append(username).append("\n");
	    sb.append("  accounts:\n");

	    if (accounts.isEmpty()) {
	        sb.append("    (none)\n");
	    } else {
	        for (PersonalAccount acc : accounts) {
	            sb.append(acc.toString("    "));
	        }
	    }

	    sb.append("}\n");
	    return sb.toString();
	}




	

}
