package model.actors;

public class Manager {

    
}