package model.actors;

public class BusinessClient extends Client {
    
    private BusinessAccount account;
    
    
    public BusinessClient(String username, String password, String fullName, String afm,
    					  String phone,BusinessAccount account) {
        
    	super(username, password,fullName,afm,phone);
        this.account=account;
    }

	@Override
	public void viewAccountBalance() {
		// TODO Auto-generated method stub
		
	}

	public BusinessAccount getAccount() {
		return account;
	}
	
	public void addBusinessAccount(BusinessAccount account) {
		this.account = account;
	}

	public void setAccount(BusinessAccount account) {
		this.account = account;
	}

	@Override
	public void viewTransactionHistory() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String toString() {

	    StringBuilder sb = new StringBuilder();

	    sb.append("══════════════ BUSINESS CLIENT ══════════════\n");

	    sb.append("Company Name : ").append(fullName).append("\n");
	    sb.append("Username     : ").append(username).append("\n");
	    sb.append("AFM          : ").append(afm).append("\n");
	    sb.append("Phone        : ").append(phone).append("\n");

	    sb.append("\nAccounts:\n");

	    if (account == null) {
	        sb.append("  (no business accounts)\n");
	    } else {
	        
	            sb.append("  ─────────────────────────────\n");
	            sb.append("  IBAN          : ").append(account.getIban()).append("\n");
	            sb.append("  Owner         : ").append(account.getOwner()).append("\n");
	            sb.append("  Balance       : ")
	              .append(String.format("%.2f €", account.getBalance())).append("\n");
	            sb.append("  Interest Rate : ").append(account.getInterestRate()).append("%\n");
	            sb.append("  Monthly Fee   : ")
	              .append(String.format("%.2f €", account.getMonthly_upkeep_fee()))
	              .append("\n");
	        }

	    sb.append("══════════════════════════════════════════════");	

	    return sb.toString();
	}


	
	
    
}