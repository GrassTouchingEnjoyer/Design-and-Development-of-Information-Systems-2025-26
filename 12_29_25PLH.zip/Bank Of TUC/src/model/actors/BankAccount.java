package model.actors;

import java.util.ArrayList;

import model.capitalTransfer.Bill;
import model.capitalTransfer.Transaction;

public abstract class BankAccount {
	
	protected final String iban;
	protected final String owner;
	protected float interestRate;
	protected double balance;
	protected AccountStatus status;
	protected ArrayList<Bill> bills;
	protected ArrayList<Transaction> transactions;
	//lista apo bills
	//lista apo transactions
	
	public BankAccount(String iban, String owner,float interestRate,double balance) {
		this.iban=iban;
		this.owner=owner;
		this.interestRate=interestRate;
		this.balance=balance;
	}
	
	
	public abstract void applyInterest();
	
	
	public void block() {
		status=AccountStatus.BLOCKED;
	}
	
	public void unblock() {
		status=AccountStatus.ACTIVE;
	}
	
	public void addBill(Bill bill) {
		bills.add(bill);
	}
	
	public void addTransaction(Transaction transaction) {
		transactions.add(transaction);
	}
	
	
	
	public float getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(float interestRate) {
		this.interestRate = interestRate;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public AccountStatus getStatus() {
		return status;
	}

	public String getIban() {
		return iban;
	}

	public String getOwner() {
		return owner;
	}

	public void setStatus(AccountStatus status) {
		this.status = status;
	}





	enum AccountStatus {
		  ACTIVE,
		  BLOCKED
		  //CLOSED
		}

}
