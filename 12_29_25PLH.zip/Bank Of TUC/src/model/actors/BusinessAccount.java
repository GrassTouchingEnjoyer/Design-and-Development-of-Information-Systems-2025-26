package model.actors;

import java.util.ArrayList;

import model.capitalTransfer.*;

public class BusinessAccount extends BankAccount{
	
	private float monthly_upkeep_fee = 0; // 12/29/2025 new
	private ArrayList<Bill> bills_forwarded;
	
	public BusinessAccount(String iban, String owner, float interestRate, double balance, float monthly_upkeep_fee) {
		
		super(iban, owner, interestRate, balance);		
		this.monthly_upkeep_fee = monthly_upkeep_fee;
		this.bills_forwarded = new ArrayList<>();
	}

	@Override
	public void applyInterest() {
		// TODO Auto-generated method stub
		
	}
	
	public float getMonthly_upkeep_fee() {
		return monthly_upkeep_fee;
	}

	public void setMonthly_upkeep_fee(int monthly_upkeep_fee) {
		this.monthly_upkeep_fee = monthly_upkeep_fee;
	}

	public void createBill(Bill new_bill){
		
		this.bills_forwarded.add(new_bill);
		
	}
	
	public void deleteBill(){
		
	}

	@Override
	public String toString() {
		return  iban + "\nowner=" + owner
				;
	}


	
	
}
