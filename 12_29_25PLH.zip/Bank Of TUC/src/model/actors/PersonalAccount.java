package model.actors;

import java.util.ArrayList;

import model.capitalTransfer.StandingOrder;
import model.capitalTransfer.StandingOrderBill;
import model.capitalTransfer.StandingOrderTransfer;

public class PersonalAccount extends BankAccount {

    private ArrayList<StandingOrder> standingOrders;   // the only real list you have now
    private ArrayList<PersonalClient> coOwners;

    public PersonalAccount(String iban, String owner, float interestRate, double balance) {
        super(iban, owner, interestRate, balance);
        this.standingOrders = new ArrayList<>();
        this.coOwners = new ArrayList<>();
    }

    public ArrayList<PersonalClient> getCoOwners() {
        return coOwners;
    }

    public void addCoOwner(PersonalClient p) {
        if (p != null) coOwners.add(p);
    }

    public void addStandingOrderBill(StandingOrderBill standing_order_bill) {
        if (standing_order_bill != null) standingOrders.add(standing_order_bill);
    }

    public void addStandingOrderTransfer(StandingOrderTransfer standing_order_transfer) {
        if (standing_order_transfer != null) standingOrders.add(standing_order_transfer);
    }

    @Override
    public void applyInterest() {
        // TODO Auto-generated method stub
    }

    public void createStandingOrder() {
        // placeholder
    }

    public void withdraw(double amount) {
        this.balance -= amount;
    }

    public void deposit(double amount) {
        this.balance += amount;
    }

    // ────────────────────────────────────────────────────────────────
    //                              toString
    // ────────────────────────────────────────────────────────────────
    @Override
    public String toString() {
        return toString("");
    }

    public String toString(String indent) {
        StringBuilder sb = new StringBuilder();
        String child = indent + "  ";

        sb.append(indent).append("PersonalAccount {\n");

        sb.append(child).append("IBAN          : ").append(getIban()).append("\n");         // assuming BankAccount has getIban()
        sb.append(child).append("Owner         : ").append(getOwner()).append("\n");        // assuming BankAccount has getOwner()
        sb.append(child).append("Interest Rate : ").append(getInterestRate()).append("%\n"); // assuming getters exist
        sb.append(child).append("Balance       : ").append(getBalance()).append("\n");      // assuming getBalance()

        // Co-Owners
        sb.append(child).append("Co-Owners     : ");
        if (coOwners.isEmpty()) {
            sb.append("none\n");
        } else {
            sb.append("\n");
            for (PersonalClient pc : coOwners) {
                sb.append(child).append("  - ").append(pc.getFullName()).append("\n");
            }
        }

        // Standing Orders (polymorphic - only what actually exists)
        sb.append(child).append("Standing Orders: ");
        if (standingOrders.isEmpty()) {
            sb.append("none\n");
        } else {
            sb.append("\n");
            for (StandingOrder so : standingOrders) {
                if (so instanceof StandingOrderBill bill) {
                    sb.append(child).append("  [Bill] ")
                      .append("Code: ").append(bill.getBillCode() != null ? bill.getBillCode() : "-")
                      .append(" | Name: ").append(bill.getName() != null ? bill.getName() : "-")
                      .append(" | €").append(bill.getAmount())
                      .append(" | ").append(bill.getIssueDate() != null ? bill.getIssueDate() : "-")
                      .append(" → ").append(bill.getDueDate() != null ? bill.getDueDate() : "-")
                      .append("\n");
                }
                else if (so instanceof StandingOrderTransfer tr) {
                    sb.append(child).append("  [Transfer] ")
                      .append("Name: ").append(tr.getName() != null ? tr.getName() : "-")
                      .append(" | €").append(tr.getAmount())
                      .append(" → ").append(tr.getReciever() != null ? tr.getReciever() : "-")
                      .append(" | Every ").append(tr.getFrequency()).append(" mo")
                      .append(" | Exec: ").append(tr.getExeDate() != null ? tr.getExeDate() : "-")
                      .append("\n");
                }
                else {
                    sb.append(child).append("  [Other StandingOrder] ").append(so).append("\n");
                }
            }
        }

        sb.append(indent).append("}\n");
        return sb.toString();
    }
}