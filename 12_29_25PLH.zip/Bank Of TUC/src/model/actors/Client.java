package model.actors;

public abstract class Client extends User {
    
    
    
    public Client(String username, String password, String fullName, String afm, String phone) {
        super(username, password,fullName,afm,phone);
        
    }
    
    public abstract void viewAccountBalance();
    public abstract void viewTransactionHistory();
    
    
    

}
