package model.actors;

public class BankStaff extends User {

	public BankStaff(String username, String password, String fullName, String afm, String phone) {
		super(username, password, fullName, afm, phone);
		// TODO Auto-generated constructor stub
	}
    
    
    

    

}