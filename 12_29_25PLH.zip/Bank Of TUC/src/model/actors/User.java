package model.actors;

import java.util.ArrayList;
import java.util.List;


public abstract class User {
    
    protected String username;
    protected String password;
    
    protected String fullName;
    protected String afm;
    protected String phone;
    
    
    public User(String username, String password, String fullName, String afm, String phone) {
        this.username = username;
        this.password = password;
        
        this.fullName = fullName;
        this.afm = afm;
        this.phone = phone;
        //this.authenticated = false;
    }
    
    public boolean login(String enteredUsername, String enteredPassword) {
        if (this.username.equals(enteredUsername) && this.password.equals(enteredPassword)) {
            //this.authenticated = true;
            System.out.println("[LOGIN] successfull: " + username);
            return true;
        }
        System.out.println("[LOGIN] failed�");
        return false;
    }
    /*
    public void logout() {
        //this.authenticated = false;
        System.out.println("[LOGOUT] Αποσ�?νδεση: " + username);
    }*/
    
    
    public String getUsername() {
        return username;
    }

	public String getFullName() {
		return fullName;
	}

    
    /*
    public boolean isAuthenticated() {
        return authenticated;
    }*/
	
	
	
	
	
}