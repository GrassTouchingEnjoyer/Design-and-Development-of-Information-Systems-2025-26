package model.capitalTransfer;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import model.actors.*;

public class Bill {
	
	private final BusinessClient issuer;
	private final String billId;
	private final String billCode;
	private final PersonalClient payer; 
	private final double amount;
	private final LocalDate issueDate;
	private final LocalDate dueDate;
	private final String description;
	private BillStatus status;
	
	
	public Bill(BusinessClient issuer, String billId, String billCode, PersonalClient payer, double amount,
			LocalDate issueDate, LocalDate dueDate, String description) {
		this.issuer = issuer;
		this.billId = billId;
		this.billCode = billCode;
		this.payer = payer;
		this.amount = amount;
		this.issueDate = issueDate;
		this.dueDate = dueDate;
		this.description = description;
	}
	
	@Override
	public String toString() {

	    DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");

	    StringBuilder sb = new StringBuilder();

	    sb.append("────────────── BILL ──────────────\n");

	    sb.append("Bill ID      : ").append(billId).append("\n");
	    sb.append("Bill Code    : ").append(billCode).append("\n");
	    sb.append("Status       : ").append(status != null ? status : "PENDING").append("\n");
	    sb.append("Amount       : ").append(String.format("%.2f €", amount)).append("\n");

	    sb.append("\nIssuer       : ")
	      .append(issuer != null ? issuer.getFullName() : "N/A").append("\n");

	    sb.append("Payer        : ")
	      .append(payer != null ? payer.getFullName() : "N/A").append("\n");

	    sb.append("\nIssue Date   : ")
	      .append(issueDate != null ? issueDate.format(fmt) : "N/A").append("\n");

	    sb.append("Due Date     : ")
	      .append(dueDate != null ? dueDate.format(fmt) : "N/A").append("\n");

	    sb.append("\nDescription  : ")
	      .append(description != null && !description.isEmpty() ? description : "-")
	      .append("\n");

	    sb.append("──────────────────────────────────");

	    return sb.toString();
	}

	
	
	public boolean isOverDue() {
	    if (dueDate == null || status == BillStatus.PAYED || status == BillStatus.CANCELED) {
	        return false;
	    }
	    boolean res = LocalDate.now().isAfter(dueDate);
	    if(res) {
	    	status=BillStatus.OVERDUE;
	    	return res;
	    }else return false;
	    
	}
	
	public void markAsPaid() {
		status=BillStatus.PAYED;
	}
	
	public void markAsCanceled() {
		status=BillStatus.CANCELED;
	}
	
	
	
	public BillStatus getStatus() {
		return status;
	}

	public void setStatus(BillStatus status) {
		this.status = status;
	}

	public BusinessClient getIssuer() {
		return issuer;
	}

	public String getBillId() {
		return billId;
	}

	public String getBillCode() {
		return billCode;
	}

	public PersonalClient getPayer() {
		return payer;
	}

	public double getAmount() {
		return amount;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public String getDescription() {
		return description;
	}

	enum BillStatus{
		PENDING,
		PAYED,
		OVERDUE,
		CANCELED
	}
	
	
	
}
