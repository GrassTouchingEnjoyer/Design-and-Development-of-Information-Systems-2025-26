package model.capitalTransfer;

import java.time.LocalDate;

import model.actors.PersonalAccount;
import model.actors.PersonalClient;

public class StandingOrderBill extends StandingOrder{
	
	private String billCode;

	public StandingOrderBill(String description, String name, PersonalClient owner, double amount,
			PersonalAccount account, LocalDate issueDate, LocalDate dueDate, double fees,String billCode) {
		super(description, name, owner, amount, account, issueDate, dueDate, fees);
		// TODO Auto-generated constructor stub
		this.billCode=billCode;
	}

	public String getBillCode() {
		return billCode;
	}

	public void setBillCode(String billCode) {
		this.billCode = billCode;
	}
	
}
