package model.capitalTransfer;

import java.time.LocalDate;

import model.actors.*;

public abstract class StandingOrder {
	
	protected String description;
	protected String name;
	protected PersonalClient owner;
	protected double amount;
	protected PersonalAccount account;
	protected LocalDate issueDate;
	protected LocalDate dueDate;
	protected double fees;
	
	
	public StandingOrder(String description, String name, PersonalClient owner, double amount, PersonalAccount account,
			LocalDate issueDate, LocalDate dueDate,double fees) {
		super();
		this.description = description;
		this.name = name;
		this.owner = owner;
		this.amount = amount;
		this.account = account;
		this.issueDate = issueDate;
		this.dueDate = dueDate;
		this.fees = fees;
	}
	
	
	
	

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public PersonalClient getOwner() {
		return owner;
	}

	public void setOwner(PersonalClient owner) {
		this.owner = owner;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public PersonalAccount getAccount() {
		return account;
	}

	public void setAccount(PersonalAccount account) {
		this.account = account;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}
}
