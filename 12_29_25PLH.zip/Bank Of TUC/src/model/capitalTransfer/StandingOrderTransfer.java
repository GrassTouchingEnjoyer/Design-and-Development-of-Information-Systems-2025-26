package model.capitalTransfer;

import java.time.LocalDate;

import model.actors.PersonalAccount;
import model.actors.PersonalClient;

public class StandingOrderTransfer extends StandingOrder{
	
	private int frequency;
	private LocalDate exeDate;
	private String reciever;
	

	public StandingOrderTransfer(String description, String name, PersonalClient owner, double amount,
			PersonalAccount account, LocalDate issueDate, LocalDate dueDate, double fees, int frequency,
			LocalDate exeDate ,String reciever ) {
		super(description, name, owner, amount, account, issueDate, dueDate,fees);
		// TODO Auto-generated constructor stub
		this.frequency=frequency;
		this.exeDate=exeDate;
		this.reciever=reciever;
	}


	public int getFrequency() {
		return frequency;
	}

	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}

	public LocalDate getExeDate() {
		return exeDate;
	}

	public void setExeDate(LocalDate exeDate) {
		this.exeDate = exeDate;
	}

	public String getReciever() {
		return reciever;
	}

	public void setReciever(String reciever) {
		this.reciever = reciever;
	}
	
	
}
