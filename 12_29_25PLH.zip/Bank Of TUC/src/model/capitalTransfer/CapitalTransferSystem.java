package model.capitalTransfer;

public class CapitalTransferSystem {

}
