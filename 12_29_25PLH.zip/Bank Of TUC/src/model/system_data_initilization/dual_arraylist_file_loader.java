package model.system_data_initilization;

import java.util.ArrayList;

import model.actors.Administrator;
import model.actors.BusinessAccount;
import model.actors.BusinessClient;
import model.actors.PersonalAccount;
import model.actors.PersonalClient;

/*
 * made as a clean data structure to save the 2 data types we need in lists
 * 
 */


public class dual_arraylist_file_loader {

    private ArrayList<PersonalClient> 	p_c = new ArrayList<>();
    private ArrayList<BusinessClient> 	b_c = new ArrayList<>();
    private ArrayList<Administrator>  	adm = new ArrayList<>();
    private ArrayList<PersonalAccount>  p_a = new ArrayList<>();    
    private ArrayList<BusinessAccount>  b_a = new ArrayList<>();   
    
    	    
    public void addAdministrator(Administrator client) { // adds administrator 
    	adm.add(client);
    }   
    													   // ArrayList<PersonalClient> add ▄ to the list (▄ ▄)
    public void addPersonalClient(PersonalClient client) { // for the addition process 
        p_c.add(client);
    }
    													   // ArrayList<BusinessClient> add ▄ to the list (▄ ▄ ▄ ▄)
    public void addBusinessClient(BusinessClient client) { // for the addition process
        b_c.add(client);
    }

    public void addBusinessAccount(BusinessAccount client) { 
        b_a.add(client);
    }
    
    public void addPersonalAccount(PersonalAccount client) { 
        p_a.add(client);
    }    

    public ArrayList<PersonalAccount> getAllPersonalAccounts() { // returns the physical clients ArrayList
        return p_a;
    }    
    
    public ArrayList<BusinessAccount> getAllBusinessAccounts() { // returns the physical clients ArrayList
        return b_a;
    }     
    
    public ArrayList<PersonalClient> getAllPersonalClients() { // returns the physical clients ArrayList
        return p_c;
    }

    public ArrayList<Administrator> getAdministrator() { // returns if it happens to be more than expected
        return adm;
    }    
    
    public ArrayList<BusinessClient> getAllBusinessClients() { // returns the business clients ArrayList
        return b_c;
    }

}
