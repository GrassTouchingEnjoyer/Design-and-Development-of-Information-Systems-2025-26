package model.system_data_initilization;

import static utils.utils.print;
import static utils.utils.random_len_x_digit_number;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;

import model.actors.Administrator;
import model.actors.BusinessAccount;
import model.actors.BusinessClient;
import model.actors.PersonalAccount;
import model.actors.PersonalClient;
import model.capitalTransfer.Bill;
import model.capitalTransfer.StandingOrderBill;
import model.capitalTransfer.StandingOrderTransfer;

public class file_loader {

    private String file_1 = "data/database.csv";
    private String file_2 = "data/trlogariasmoi.csv";    
    private String file_3 = "data/pagiesentoles.csv";    
    private String file_4 = "data/logariasmoiplhrwmwn.csv";
    
    public dual_arraylist_file_loader read_csv() {
    	
        dual_arraylist_file_loader loader = new dual_arraylist_file_loader();        
//___________________________________________________________________________________________________________
        try (BufferedReader reader = new BufferedReader(new FileReader(file_1))) {
            
        	String line;
            
            while ((line = reader.readLine()) != null) {
            	
            	  //filter_____________________________________________________________________________________           	
	                
            		line = line.trim();
	                
	                if(line.isEmpty()){continue;}
	            		          		
	                String[] row = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
	                
	                if(row.length < 1) continue; // need at least 1 columns 
	                
	               //___________________________________________________________________________________________   
                
                switch (row[0].trim()) {
                
                	//___________________________________________________username,password,fullName,afm,phone
                	case "ΔΙΑΧΕΙΡΙΣΤΗΣ":
                		
                		loader.addAdministrator(new Administrator(
                				
                				row[2].trim(),
                				"123" ,
                				row[1].trim()
                				,"0"
                				,"0" 
                		));              		
                		break;
                	
                    //___________________________________________________username,password,fullName,afm,phone 
                    case "Φ.ΠΡΟΣΩΠΟ":                                      	
                    	
                        loader.addPersonalClient(new PersonalClient(
                        											
								row[2].trim(),
								"123" ,
								row[1].trim(), 
								row[3].trim(), 
								random_len_x_digit_number(10)							
								
							    //null user accounts ++ (1)[10:55pm]
								//will make file_loader_accounts.java to load in the list with the accounts of each client(2)[11:28pm]
								//
								//++
                        ));
                        break;         
                        
                    //______________________________________username, password, fullName, afm, phone, account    
                    case "Ν.ΠΡΟΣΩΠΟ":                    	                  	
                    	
                        loader.addBusinessClient(new BusinessClient(
                        		
                                row[2].trim(),
                                "123",
                                row[1].trim(),
                                row[3].trim(),
								random_len_x_digit_number(10),
								null //business account 
                        ));
                        break;
                    //_______________________________________________________________________________________ 
                }
            }
                                                   
        }catch (IOException e){e.printStackTrace();}
//___________________________________________________________________________________________________________         
        
        
        
        
//___________________________________________________________________________________________________________        
        try (BufferedReader reader = new BufferedReader(new FileReader(file_2))) {
        
	    	String line;
	        
	        while ((line = reader.readLine()) != null) {
          	   
	            //filter_____________________________________________________          	             

	        		line = line.trim();
	                
	                if(line.isEmpty()) continue;
	            		          		
	                String[] row = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
	                
	                if(row.length < 2) continue; // need at least 2 columns 	                
	            //___________________________________________________________
	             
	              //__________________________________________________________________________________
	                for (PersonalClient p_c : loader.getAllPersonalClients()) {

	                    if (p_c.getFullName().equals(row[1].trim())) {

	                        float interestRate = Float.parseFloat(
	                        row[2].trim().replace("€", "").replace("%", "").replace("\"", "").replace(",", ""));

	                        double balance = Double.parseDouble(
	                        row[3].trim().replace("€", "").replace("%", "").replace("\"", "").replace(",", ""));

	                        PersonalAccount account = new PersonalAccount(
	                            row[0].trim(),   // IBAN
	                            row[1].trim(),   // owner
	                            interestRate,
	                            balance
	                        );

	                        p_c.addPersonalAccount(account);

	                        // handle co-owners
	                        if (row.length > 5 && !row[5].trim().isEmpty()) {

	                            String[] coOwners = row[5]
	                                    .replace("\"", "")
	                                    .split(",");

	                            for (String coOwnerName : coOwners) {

	                                String name = coOwnerName.trim();

	                                for (PersonalClient p_c_co : loader.getAllPersonalClients()) {

	                                    if (p_c_co.getFullName().equals(name)) {
	                                        account.addCoOwner(p_c_co);
	                                    }
	                                }
	                            }
	                        }
	                    }
	                }
	                //__________________________________________________________________________________
               
	                
	                //__________________________________________________________________________________
	                for (BusinessClient b_c : loader.getAllBusinessClients()) {  // iterate over clients

	                    if (b_c.getFullName().equals(row[1].trim())) {           // match by full name

	                        // Parse the interest rate and balance safely
	                        float interestRate = Float.parseFloat(row[2].trim().replace("%", ""));
	                        double balance = Double.parseDouble(row[3].trim().replace("€", "").replace("€", "")
																							  .replace("€", "")
																							  .replace("%", "")
																						      .replace(",", "")
																							  .replace("\"", ""));
	                        
	                        float monthly_upkeep_fee = Float.parseFloat(row[4].trim().replace("€", "").replace("€", "")
																									  .replace("€", "")
																									  .replace("%", "")
																								      .replace(",", "")
																									  .replace("\"", ""));
	                        
	                        
	                        // Create new PersonalAccount and add to the client
	                        BusinessAccount account = new BusinessAccount(
	                            row[0].trim(),   	// IBAN
	                            row[1].trim(),   	// owner/full name
	                            interestRate,    	// interest rate
	                            balance,         	// balance
	                            monthly_upkeep_fee
	                        );

	                        b_c.addBusinessAccount(account);
	                    }
	                }
	                //__________________________________________________________________________________	                               
	                
	        }
        
        
        }catch (IOException e){e.printStackTrace();}           
//___________________________________________________________________________________________________________ 
        
        
        
        
//___________________________________________________________________________________________________________        
        try (BufferedReader reader = new BufferedReader(new FileReader(file_3))) {

            String line;
            boolean readingBills = false;
            boolean readingTransfers = false;

            while ((line = reader.readLine()) != null) {

                line = line.trim();
                if (line.isEmpty()) continue;

                String[] row = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

                // SECTION SWITCH
                if (line.contains("ΠΑΓΙΕΣ ΕΝΤΟΛΕΣ ΠΛΗΡΩΜΗΣ")) {
                    readingBills = true;
                    readingTransfers = false;
                    continue;
                }

                if (line.contains("ΠΑΓΙΕΣ ΕΝΤΟΛΕΣ ΜΕΤΑΦΟΡΑΣ")) {
                    readingBills = false;
                    readingTransfers = true;
                    continue;
                }

                // ===================================================
                // ================== STANDING ORDER BILL ============
                // ===================================================
                if (readingBills && row.length >= 10 && !row[1].isEmpty()) {

                    String billCode   = row[1].replace("\"", "").trim();
                    String name       = row[2].replace("\"", "").trim();
                    String description= row[3].replace("\"", "").trim();
                    String ownerName  = row[4].trim();

                    double amount = Double.parseDouble(
                            row[5].replace("€", "").replace(",", "").trim()
                    );

                    LocalDate issueDate = LocalDate.parse(row[6].trim());
                    LocalDate dueDate   = LocalDate.parse(row[7].trim());
                    double fees         = Double.parseDouble(row[8].trim());
                    String iban         = row[9].trim();

                    for (PersonalClient pc : loader.getAllPersonalClients()) {
                        if (!pc.getFullName().equals(ownerName)) continue;

                        for (PersonalAccount acc : pc.getAccounts()) {
                            if (!acc.getIban().equals(iban)) continue;

                            StandingOrderBill bill = new StandingOrderBill(
                                description,
                                name,
                                pc,
                                amount,
                                acc,
                                issueDate,
                                dueDate,
                                fees,
                                billCode
                            );

                            acc.addStandingOrderBill(bill);
                        }
                    }
                }

                // ===================================================
                // ================== STANDING ORDER TRANSFER ========
                // ===================================================
                if (readingTransfers && row.length >= 12 && !row[1].isEmpty()) {

                    String name        = row[1].replace("\"", "").trim();
                    String description = row[2].replace("\"", "").trim();
                    String ownerName   = row[3].trim();

                    double amount = Double.parseDouble(
                            row[4].replace("€", "").replace(",", "").trim()
                    );

                    LocalDate issueDate = LocalDate.parse(row[5].trim());
                    LocalDate dueDate   = LocalDate.parse(row[6].trim());
                    double fees         = Double.parseDouble(row[7].trim());

                    String debitIban  = row[8].trim();
                    String receiver   = row[9].trim();
                    int frequency     = Integer.parseInt(row[10].trim());
                    LocalDate exeDate = LocalDate.of(
                                            issueDate.getYear(),
                                            issueDate.getMonth(),
                                            Integer.parseInt(row[11].trim())
                                        );

                    for (PersonalClient pc : loader.getAllPersonalClients()) {
                        if (!pc.getFullName().equals(ownerName)) continue;

                        for (PersonalAccount acc : pc.getAccounts()) {
                            if (!acc.getIban().equals(debitIban)) continue;

                            StandingOrderTransfer transfer = new StandingOrderTransfer(
                                description,
                                name,
                                pc,
                                amount,
                                acc,
                                issueDate,
                                dueDate,
                                fees,
                                frequency,
                                exeDate,
                                receiver
                            );

                            acc.addStandingOrderTransfer(transfer);
                        }
                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

                 
//___________________________________________________________________________________________________________   
        
        
        
        
        
      //___________________________________________________________________________________________________________        
        try (BufferedReader reader = new BufferedReader(new FileReader(file_4))) {

            String line;

            while ((line = reader.readLine()) != null) {

                line = line.trim();
                if (line.isEmpty()) continue;

                String[] row = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

                if (row.length < 7 || row[0].equals("ΕΚΔΟΤΗΣ")) continue;

                String issuerName   = row[0].trim();
                String billCode     = row[1].trim();
                String billId       = row[2].trim();
                String payerName    = row[3].trim();
                double amount       = Double.parseDouble(
                                        row[4].replace("€","").replace(",","").trim()
                                      );
                LocalDate issueDate = LocalDate.parse(row[5].trim());
                LocalDate dueDate   = LocalDate.parse(row[6].trim());

                BusinessClient issuer = null;
                PersonalClient payer  = null;

                for (BusinessClient bc : loader.getAllBusinessClients()) {
                    if (bc.getFullName().equals(issuerName)) {
                        issuer = bc;
                        break;
                    }
                }

                for (PersonalClient pc : loader.getAllPersonalClients()) {
                    if (pc.getFullName().equals(payerName)) {
                        payer = pc;
                        break;
                    }
                }

                if (issuer == null || payer == null) continue;

                Bill bill = new Bill(
                    issuer,
                    billId,
                    billCode,
                    payer,
                    amount,
                    issueDate,
                    dueDate,
                    "Utility Bill"
                );


                issuer.getAccount().createBill(bill);
                //CHANGE THE STREAM OF THE BILL
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        //___________________________________________________________________________________________________________         

                 
//___________________________________________________________________________________________________________         
        
        
        
        
        
        return loader;
    }
}
