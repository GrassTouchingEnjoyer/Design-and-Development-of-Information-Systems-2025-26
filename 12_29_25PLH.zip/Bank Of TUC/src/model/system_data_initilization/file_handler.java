package model.system_data_initilization;


import java.util.ArrayList;

import model.actors.Administrator;
import model.actors.BusinessClient;
import model.actors.PersonalClient;


//______________________________________| the dao interface |

interface file_handler_dao_contract{ 
	
    public ArrayList<PersonalClient> getAllPhysicalClients();
    public ArrayList<BusinessClient> getAllBusinessClients();	
	
}
//___________________________________________________________

public class file_handler implements file_handler_dao_contract{ 
	
	private ArrayList<Administrator>  admins;
    private ArrayList<PersonalClient> physical_clients;
    private ArrayList<BusinessClient> business_clients;
    //private ArrayList<BusinessAccount> business_accounts;
    //private ArrayList<PersonalAccount> business_accounts;    
    //++ add lists to return here
    
    
    
    
    
    //____________________________________________|constructor|
    
    public file_handler() { 
        
    	file_loader loader = new file_loader();

        // call the dual_arraylist
        dual_arraylist_file_loader data = loader.read_csv();      
        
        this.admins 		  = data.getAdministrator();
        this.physical_clients = data.getAllPersonalClients(); 
        this.business_clients = data.getAllBusinessClients();                               
    }
    //_________________________________________________________
    
    
    
    
    
    //___________________________________________|get all lists|
   
    public ArrayList<Administrator> getAllAdministrators() {
        return admins;
    }
    
    
    public ArrayList<PersonalClient> getAllPhysicalClients() {
        return physical_clients;
    }
    
    

    public ArrayList<BusinessClient> getAllBusinessClients() {
        return business_clients;
    }
   //_________________________________________________________
    
    
    
    
    
    
    //_______________________________________________|ToString|
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("Admins:\n");
        for (Administrator ad : admins) {
            sb.append(ad.toString()).append("\n\n");
        }
        
        sb.append("Personal Clients:\n");
        for (PersonalClient pc : physical_clients) {
            sb.append(pc.toString()).append("\n");
        }

        sb.append("\nBusiness Clients:\n");
        for (BusinessClient bc : business_clients) {
            sb.append(bc.toString()).append("\n");
        }

        return sb.toString();}
    //_________________________________________________________
    
    
}
