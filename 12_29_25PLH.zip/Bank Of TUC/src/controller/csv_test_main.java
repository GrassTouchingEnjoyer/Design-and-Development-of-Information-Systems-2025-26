package controller;

import static utils.utils.print;
import static utils.utils.random_len_x_digit_number;

import model.system_data_initilization.file_handler;

public class csv_test_main {

	public static void main(String[] args) {

		print(random_len_x_digit_number(10));
		
		file_handler x = new file_handler();
		print(x.toString());
		

	}

}
