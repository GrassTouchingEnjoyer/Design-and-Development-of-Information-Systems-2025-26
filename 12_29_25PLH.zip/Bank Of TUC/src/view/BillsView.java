package view;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class BillsView extends JPanel {

    private JPanel billsContainer;
    private JScrollPane scrollPane;
    private JButton backButton;

    public BillsView() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titleLabel = new JLabel("����������� ��������");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);

        billsContainer = new JPanel();
        billsContainer.setLayout(new BoxLayout(billsContainer, BoxLayout.Y_AXIS));
        billsContainer.setAlignmentY(Component.TOP_ALIGNMENT);

        scrollPane = new JScrollPane(billsContainer);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        // Bottom panel �� ������ ����
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        backButton = new JButton("����");
        bottomPanel.add(backButton);

        add(titleLabel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    public void clearBills() {
        billsContainer.removeAll();
        billsContainer.revalidate();
        billsContainer.repaint();
    }

    public void addBill(String description, double amount, Runnable onPay) {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));

        // ������� ��� ������������ ������� ��� �� ��������
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));
        panel.setMinimumSize(new Dimension(400, 60));
        panel.setPreferredSize(new Dimension(400, 60));

        JLabel label = new JLabel(description + " - " + String.format("%.2f �", amount));
        label.setFont(new Font("Arial", Font.PLAIN, 16));
        label.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0)); // padding ��������

        JButton payButton = new JButton("�������");
        payButton.addActionListener(e -> onPay.run());

        panel.add(label, BorderLayout.CENTER);
        panel.add(payButton, BorderLayout.EAST);

        billsContainer.add(panel);
        billsContainer.add(Box.createVerticalStrut(5)); // ���� ���� �������

        billsContainer.revalidate();
        billsContainer.repaint();
    }
    
    public JButton getBackButton() {
        return backButton;
    }
}


