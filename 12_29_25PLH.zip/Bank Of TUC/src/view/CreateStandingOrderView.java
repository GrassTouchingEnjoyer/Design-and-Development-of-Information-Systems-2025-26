package view;

import javax.swing.*;
import java.awt.*;

public class CreateStandingOrderView extends JPanel {

    // Common
    private JTextField nameField;
    private JTextArea descriptionArea;

    // Transfer fields
    private JTextField ibanField;
    private JTextField amountField;
    private JTextField frequencyField;
    private JTextField executionDayField;

    // Payment fields
    private JTextField paymentCodeField;
    private JTextField maxAmountField;
    private JTextField activeUntilField;

    private JPanel transferPanel;
    private JPanel paymentPanel;

    private JButton createButton;
    private JButton backButton;
    private JComboBox<String> typeCombo;

    public CreateStandingOrderView() {
        setLayout(new BorderLayout(20, 20));
        setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));

        Font labelFont = new Font("Arial", Font.PLAIN, 18);
        Font fieldFont = new Font("Arial", Font.PLAIN, 18);
        Font titleFont = new Font("Arial", Font.BOLD, 26);
        Font buttonFont = new Font("Arial", Font.BOLD, 18);

        JLabel title = new JLabel("���������� ������ �������", SwingConstants.CENTER);
        title.setFont(titleFont);

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

        // -------- TRANSFER PANEL --------
        transferPanel = new JPanel(new GridBagLayout());
        transferPanel.setBorder(BorderFactory.createTitledBorder("����� ��������"));
        addTransferFields(transferPanel, labelFont, fieldFont);

        // -------- PAYMENT PANEL --------
        paymentPanel = new JPanel(new GridBagLayout());
        paymentPanel.setBorder(BorderFactory.createTitledBorder("����� �������"));
        addPaymentFields(paymentPanel, labelFont, fieldFont);
        paymentPanel.setVisible(false);

        centerPanel.add(transferPanel);
        centerPanel.add(paymentPanel);

        // -------- BUTTONS + COMBO --------
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));

        backButton = new JButton("����");
        createButton = new JButton("����������");

        backButton.setFont(buttonFont);
        createButton.setFont(buttonFont);

        typeCombo = new JComboBox<>(new String[]{"��������", "�������"});
        typeCombo.setFont(fieldFont);

        bottomPanel.add(backButton);
        bottomPanel.add(typeCombo);
        bottomPanel.add(createButton);

        add(title, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        typeCombo.addActionListener(e -> updatePanels());
    }

    // ---------- TRANSFER ----------
    private void addTransferFields(JPanel panel, Font labelFont, Font fieldFont) {
        GridBagConstraints gbc = baseGbc();

        int row = 0;
        ibanField = addField(panel, gbc, row++, "IBAN:", labelFont, fieldFont);
        amountField = addField(panel, gbc, row++, "��������� ����:", labelFont, fieldFont);
        frequencyField = addField(panel, gbc, row++, "��������� (�����):", labelFont, fieldFont);
        executionDayField = addField(panel, gbc, row++, "����� ���������:", labelFont, fieldFont);
        activeUntilField = addField(panel, gbc, row++, "������ ���:", labelFont, fieldFont);

        nameField = addField(panel, gbc, row++, "��������:", labelFont, fieldFont);
        descriptionArea = addTextArea(panel, gbc, row, "���������:", labelFont, fieldFont);
    }

    // ---------- PAYMENT ----------
    private void addPaymentFields(JPanel panel, Font labelFont, Font fieldFont) {
        GridBagConstraints gbc = baseGbc();

        int row = 0;
        paymentCodeField = addField(panel, gbc, row++, "������� ��������:", labelFont, fieldFont);
        maxAmountField = addField(panel, gbc, row++, "������� ����:", labelFont, fieldFont);
        activeUntilField = addField(panel, gbc, row++, "������ ���:", labelFont, fieldFont);

        nameField = addField(panel, gbc, row++, "��������:", labelFont, fieldFont);
        descriptionArea = addTextArea(panel, gbc, row, "���������:", labelFont, fieldFont);
    }

    private GridBagConstraints baseGbc() {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        return gbc;
    }

    private JTextField addField(JPanel panel, GridBagConstraints gbc, int row,
                               String label, Font labelFont, Font fieldFont) {
        gbc.gridx = 0;
        gbc.gridy = row;
        JLabel l = new JLabel(label);
        l.setFont(labelFont);
        panel.add(l, gbc);

        gbc.gridx = 1;
        JTextField field = new JTextField(18);
        field.setFont(fieldFont);
        panel.add(field, gbc);

        return field;
    }

    private JTextArea addTextArea(JPanel panel, GridBagConstraints gbc, int row,
                                 String label, Font labelFont, Font fieldFont) {
        gbc.gridx = 0;
        gbc.gridy = row;
        JLabel l = new JLabel(label);
        l.setFont(labelFont);
        panel.add(l, gbc);

        gbc.gridx = 1;
        JTextArea area = new JTextArea(3, 18);
        area.setFont(fieldFont);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        panel.add(new JScrollPane(area), gbc);

        return area;
    }

    private void updatePanels() {
        boolean isTransfer = typeCombo.getSelectedItem().equals("��������");
        transferPanel.setVisible(isTransfer);
        paymentPanel.setVisible(!isTransfer);
        revalidate();
        repaint();
    }

    // -------- GETTERS --------
    public JButton getCreateButton() { return createButton; }
    public JButton getBackButton() { return backButton; }
    public JComboBox<String> getTypeCombo() { return typeCombo; }

	public JTextField getNameField() {
		return nameField;
	}

	public JTextField getIbanField() {
		return ibanField;
	}

	public JTextField getAmountField() {
		return amountField;
	}

	public JTextField getFrequencyField() {
		return frequencyField;
	}

	public JTextField getExecutionDayField() {
		return executionDayField;
	}

	public JTextField getPaymentCodeField() {
		return paymentCodeField;
	}

	public JTextField getMaxAmountField() {
		return maxAmountField;
	}

	public JTextField getActiveUntilField() {
		return activeUntilField;
	}

	public JTextArea getDescriptionArea() {
		return descriptionArea;
	}
    
}


