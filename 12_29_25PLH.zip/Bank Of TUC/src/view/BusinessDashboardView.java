package view;

import javax.swing.*;
import java.awt.*;

public class BusinessDashboardView extends JPanel {

    private JButton accountInfoButton;
    private JButton billsButton;
    //private JButton standingOrdersButton;
    private JButton blockAccountButton;
    private JButton logoutButton;


    private JLabel balanceLabel;
    private JPanel transactionsPanel;

    public BusinessDashboardView() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        Font buttonFont = new Font("Arial", Font.BOLD, 16);
        Font balanceFont = new Font("Arial", Font.BOLD, 26);

        // -------- LEFT PANEL --------
        JPanel leftPanel = new JPanel(new GridLayout(3, 1, 10, 10));
        accountInfoButton = new JButton("����������� �����������");
        billsButton = new JButton("����������� ��������");
        //standingOrdersButton = new JButton("������ �������");

        accountInfoButton.setFont(buttonFont);
        billsButton.setFont(buttonFont);
        //standingOrdersButton.setFont(buttonFont);

        leftPanel.add(accountInfoButton);
        leftPanel.add(billsButton);
        // leftPanel.add(standingOrdersButton);

        // -------- CENTER PANEL --------
        JPanel centerPanel = new JPanel(new BorderLayout());
        balanceLabel = new JLabel("��������: 25.000 �", SwingConstants.CENTER);
        balanceLabel.setFont(balanceFont);
        centerPanel.add(balanceLabel, BorderLayout.CENTER);

        // -------- RIGHT PANEL --------
        transactionsPanel = new JPanel();
        transactionsPanel.setLayout(new BoxLayout(transactionsPanel, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(transactionsPanel);

        // -------- BOTTOM PANEL --------
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        blockAccountButton = new JButton("����� �����������");
        blockAccountButton.setFont(buttonFont);
        logoutButton = new JButton("Log out");
        logoutButton.setFont(new Font("Arial", Font.BOLD, 15));
        
        bottomPanel.add(logoutButton);
        bottomPanel.add(blockAccountButton);

        add(leftPanel, BorderLayout.WEST);
        add(centerPanel, BorderLayout.CENTER);
        add(scrollPane, BorderLayout.EAST);
        add(bottomPanel, BorderLayout.SOUTH);
    }
    
    public void addTransaction(String text) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));

        JLabel label = new JLabel(text);
        label.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

        panel.add(label, BorderLayout.CENTER);

        transactionsPanel.add(panel);
        transactionsPanel.add(Box.createVerticalStrut(5));

        transactionsPanel.revalidate();
        transactionsPanel.repaint();
    }
    
    public void clearTransactions() {
        transactionsPanel.removeAll();
        transactionsPanel.revalidate();
        transactionsPanel.repaint();
    }



    // -------- GETTERS --------
    public JButton getBillsButton() { return billsButton; }
    //public JButton getStandingOrdersButton() { return standingOrdersButton; }
    public JButton getBlockAccountButton() { return blockAccountButton; }
    
    public JButton getLogoutButton() {
        return logoutButton;
    }
}

