package model.command;

public interface Command {
    CommandResult execute();
}
